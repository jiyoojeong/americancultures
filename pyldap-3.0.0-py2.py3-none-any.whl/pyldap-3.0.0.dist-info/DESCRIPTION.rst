
The pyldap fork was merged back into python-ldap,
and will be released as python-ldap 3.0.0.


